import './App.css'
import Routers from './pages/routes/Routers'

function App() {

  return (
    <>
     <Routers/>
    </>
  )
}

export default App
